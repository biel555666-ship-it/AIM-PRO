package com.aimpro.crosshair

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val cyan = Color.rgb(53, 215, 255)
    private var selectedStyle = "Cruz clássica"
    private var selectedColor = Color.WHITE
    private var sizeValue = 34

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(Color.rgb(8, 13, 22))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)

        val brand = TextView(this).apply {
            text = "AIM PRO"
            textSize = 30f
            setTextColor(cyan)
            letterSpacing = 0.12f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        content.addView(brand)
        content.addView(label("CROSSHAIR ASSISTANT  •  PREMIUM"))

        val previewCard = card()
        previewCard.addView(label("PRÉVIA DA MIRA"))
        val preview = TextView(this).apply {
            text = "＋"
            textSize = 68f
            gravity = Gravity.CENTER
            setTextColor(selectedColor)
            height = 150
        }
        previewCard.addView(preview)
        content.addView(previewCard)

        val styleCard = card()
        styleCard.addView(label("ESTILO DA MIRA"))
        val styles = arrayOf("Cruz clássica", "Ponto central", "Círculo", "Cruz fina", "Tática")
        val styleSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, styles)
            setSelection(0)
            setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {}
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    selectedStyle = styles[position]
                    preview.text = glyphFor(selectedStyle)
                }
            })
        }
        styleCard.addView(styleSpinner)
        content.addView(styleCard)

        val colorCard = card()
        colorCard.addView(label("COR"))
        val colors = arrayOf("Branco", "Azul neon", "Verde", "Vermelho", "Amarelo")
        val colorSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, colors)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {}
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    selectedColor = when(position) {
                        1 -> Color.rgb(53,215,255); 2 -> Color.GREEN; 3 -> Color.RED; 4 -> Color.YELLOW; else -> Color.WHITE
                    }
                    preview.setTextColor(selectedColor)
                }
            }
        }
        colorCard.addView(colorSpinner)
        content.addView(colorCard)

        val sizeCard = card()
        sizeCard.addView(label("TAMANHO"))
        val sizeText = label("34 px")
        val seek = SeekBar(this).apply {
            max = 70; progress = 34
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                    sizeValue = p.coerceAtLeast(12)
                    sizeText.text = "$sizeValue px"
                    preview.textSize = sizeValue * 2f
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        sizeCard.addView(sizeText); sizeCard.addView(seek)
        content.addView(sizeCard)

        val start = button("ATIVAR MIRA FLUTUANTE")
        start.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                startActivity(i)
                Toast.makeText(this, "Permita 'Sobrepor a outros apps' e volte ao AIM PRO.", Toast.LENGTH_LONG).show()
            } else {
                val i = Intent(this, CrosshairService::class.java).apply {
                    action = CrosshairService.ACTION_START
                    putExtra("style", selectedStyle)
                    putExtra("color", selectedColor)
                    putExtra("size", sizeValue)
                }
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                Toast.makeText(this, "Mira ativada. Você pode abrir o PUBG.", Toast.LENGTH_LONG).show()
            }
        }
        content.addView(start)

        val stop = button("DESATIVAR MIRA").apply {
            setBackgroundColor(Color.rgb(42, 54, 70))
            setOnClickListener { stopService(Intent(this@MainActivity, CrosshairService::class.java)) }
        }
        content.addView(stop)
        content.addView(label("A mira é apenas uma referência visual. Não altera o recuo, a precisão ou os disparos do PUBG. Use conforme as regras do jogo."))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun glyphFor(style: String) = when(style) {
        "Ponto central" -> "•"
        "Círculo" -> "⊙"
        "Cruz fina" -> "┼"
        "Tática" -> "⌖"
        else -> "＋"
    }

    private fun label(t: String) = TextView(this).apply {
        text = t; textSize = 12f; setTextColor(Color.rgb(157, 174, 194))
        setPadding(0, 10, 0, 10)
    }
    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(18, 14, 18, 14)
        setBackgroundColor(Color.rgb(17, 26, 40))
        val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 14, 0, 0)
        layoutParams = lp
    }
    private fun button(t: String) = Button(this).apply {
        text = t; setTextColor(Color.BLACK); setBackgroundColor(cyan)
        val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 18, 0, 0)
        layoutParams = lp
    }
}
