package com.aimpro.crosshair

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.Toast

class CrosshairService : Service() {
    companion object {
        const val ACTION_START = "com.aimpro.crosshair.START"
        private const val CHANNEL = "aimpro_overlay"
        private const val NOTIFICATION_ID = 41
    }
    private var windowManager: WindowManager? = null
    private var crosshairView: CrosshairView? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_START) {
            val notification = Notification.Builder(this, CHANNEL)
                .setContentTitle("AIM PRO ativo")
                .setContentText("Mira flutuante ativada")
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .build()
            startForeground(NOTIFICATION_ID, notification)
            showOverlay(
                intent.getStringExtra("style") ?: "Cruz clássica",
                intent.getIntExtra("color", Color.WHITE),
                intent.getIntExtra("size", 34)
            )
        }
        return START_STICKY
    }

    private fun showOverlay(style: String, color: Int, size: Int) {
        if (crosshairView != null) return
        val view = CrosshairView(this, style, color, size)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        windowManager?.addView(view, params)
        crosshairView = view
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "AIM PRO overlay", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        crosshairView?.let { try { windowManager?.removeView(it) } catch (_: Exception) {} }
        crosshairView = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}

class CrosshairView(context: Context, private val style: String, color: Int, private val size: Int) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color
        strokeWidth = (size / 10f).coerceAtLeast(2f)
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val x = width / 2f
        val y = height / 2f
        val r = size.toFloat()
        when(style) {
            "Ponto central" -> {
                paint.style = Paint.Style.FILL
                canvas.drawCircle(x, y, (r/7).coerceAtLeast(3f), paint)
            }
            "Círculo" -> {
                paint.style = Paint.Style.STROKE
                canvas.drawCircle(x, y, r/2, paint)
                canvas.drawCircle(x, y, 2f, paint)
            }
            "Cruz fina" -> {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 2f
                canvas.drawLine(x-r/2, y, x+r/2, y, paint)
                canvas.drawLine(x, y-r/2, x, y+r/2, paint)
            }
            "Tática" -> {
                paint.style = Paint.Style.STROKE
                canvas.drawCircle(x, y, r/3, paint)
                canvas.drawLine(x-r, y, x-r/2, y, paint)
                canvas.drawLine(x+r/2, y, x+r, y, paint)
                canvas.drawLine(x, y-r, x, y-r/2, paint)
                canvas.drawLine(x, y+r/2, x, y+r, paint)
            }
            else -> {
                paint.style = Paint.Style.STROKE
                canvas.drawLine(x-r/2, y, x+r/2, y, paint)
                canvas.drawLine(x, y-r/2, x, y+r/2, paint)
            }
        }
    }
}
